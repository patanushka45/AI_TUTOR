document.getElementById('send-btn').addEventListener('click', async () => {
    const userInput = document.getElementById('user-input').value;
  
    if (userInput.trim()) {
      appendMessage(userInput, 'user');
      document.getElementById('user-input').value = ''; // Clear input field
  
      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ message: userInput })
        });
  
        const data = await response.json();
        appendMessage(data.message, 'bot');
      } catch (error) {
        console.error('Error communicating with the server:', error);
      }
    }
  });
  
  document.getElementById('clear-btn').addEventListener('click', async () => {
    try {
      const response = await fetch('/api/clear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
  
      const data = await response.json();
      document.getElementById('chat-box').innerHTML = ''; // Clear chat box
      appendMessage(data.message, 'system');
    } catch (error) {
      console.error('Error clearing conversation history:', error);
    }
  });
  
  function appendMessage(message, sender) {
    const chatBox = document.getElementById('chat-box');
    const messageElement = document.createElement('div');
    messageElement.classList.add(sender);
    messageElement.innerText = message;
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Auto scroll to the bottom
  }
  